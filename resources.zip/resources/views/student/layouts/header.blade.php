@yield('css')
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" />
<link href="css/styles-custom.css" rel="stylesheet" />
<!-- <link href="{{asset('assets/css/wl/wl-css1.css')}}" rel="stylesheet" />
<link href="{{asset('assets/css/wl/wl-css2.css')}}" rel="stylesheet" />
<link href="{{asset('assets/css/wl/wl-css3.css')}}" rel="stylesheet" />
<link href="{{asset('assets/css/wl/wl-css4.css')}}" rel="stylesheet" />
<link href="{{asset('assets/css/wl/wl-css5.css')}}" rel="stylesheet" /> -->
<!-- <link
      href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css"
      rel="stylesheet"
    /> -->
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet" />
<script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>