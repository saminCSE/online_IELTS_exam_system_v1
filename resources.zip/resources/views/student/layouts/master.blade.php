<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>WINGS - Online Mock Test</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .hidden {
            display: none;
        }
    </style>



    @include('student.layouts.header')
</head>

<body class="sb-nav-fixed" style="background-color: #ebeff0">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-danger" style="height: 100px;">
        <div class="container d-flex justify-content-between" style="width: 100%"> <!-- Navbar Brand-->
            <!-- <img src="{{ asset('assets/img/wingslogo.png') }}" href="{{ route('studentDashboard') }}" style="padding-right: 25px;" alt="shamim"> -->
            <a class="navbar-brand" href="{{ route('studentDashboard') }}" style="font-weight: 1000;">IELTS Mock
                Test</a>
            <ul class="">
                @auth('student')
                    <li class="nav-item dropdown no-arrow" style="list-style: none">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small text-white">

                                {{ auth('student')->user()->name }}

                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="userDropdown">

                            <a class="dropdown-item" href="{{ route('student_logout') }}">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                @endauth
            </ul>
            <!-- Sidebar Toggle-->
            <!-- <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!">
            <i class="fas fa-bars"></i>
        </button> -->
            <!-- <a class="navbar-brand ps-3" href="{{ route('academic') }}">Academic</a> -->
            <!-- <a class="navbar-brand ps-3" href="{{ route('general') }}">General</a>
        <a class="navbar-brand ps-3" href="{{ route('test_score') }}">Test Score</a> -->
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">

            </form>
            <!-- Navbar-->

            <!-- <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="{{ route('student_logout') }}">Logout</a></li>
                </ul>
            </li>
        </ul> -->
        </div>
    </nav>

    <div class="main container">
        @yield('content')
    </div>
    @include('student.layouts.footer_scripts')
    @include('student.layouts.footer')
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>

</html>
