<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Listening Test - General</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />

    <link rel="stylesheet" media="all" href="https://use.fontawesome.com/releases/v6.1.0/css/all.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css" />


    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <style></style>
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
</head>

<body>
    <div class="navbar-container fixed-top">
        <!-- First Fixed Nav-Bar -->
        <nav class="navbar navbar-expand-lg navbar-light custom-navbar">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/assets/images/wingslogo_56x48.png" width="56" height="48" alt="Logo" />
                </a>
                <div class="navbar-text mx-auto clock-counter">
                    <!-- Time counter here (You can use JavaScript to update this) -->
                    <span id="time-counter">40:00</span>
                </div>
                <div class="navbar-text">
                    <!-- Icons and buttons here (Add your icons and buttons) -->
                    <!-- <button class="btn btn-primary">Button 1</button>
          <button class="btn btn-secondary">Button 2</button> -->

                    <button type="button" class="btn btn-danger bt-submit">
                        Submit <i class="fa-solid fa-angles-right fa-lg"></i>
                    </button>
                </div>
            </div>
            <div class="">
                <button class="js-toggle-fullscreen-btn toggle-fullscreen-btn" aria-label="Enter fullscreen mode" hidden>
                    <svg class="toggle-fullscreen-svg" width="28" height="28" viewBox="-2 -2 28 28">
                        <g class="icon-fullscreen-enter">
                            <path d="M 2 9 v -7 h 7" />
                            <path d="M 22 9 v -7 h -7" />
                            <path d="M 22 15 v 7 h -7" />
                            <path d="M 2 15 v 7 h 7" />
                        </g>

                        <g class="icon-fullscreen-leave">
                            <path d="M 24 17 h -7 v 7" />
                            <path d="M 0 17 h 7 v 7" />
                            <path d="M 0 7 h 7 v -7" />
                            <path d="M 24 7 h -7 v -7" />
                        </g>
                    </svg>
                </button>
            </div>
        </nav>

        <!-- Second Fixed Nav-Bar -->
        <nav class="navbar navbar-expand-lg navbar-light nav-bar-2">
            {{-- <div class="container">
                @foreach ($organizedData as $row)
                    <audio class="audio-play" id="audio-player" controls autoplay>
                        <source src="{{ asset($row['audio_file']) }}" type="audio/mpeg" />
            Your browser does not support the audio element.
            </audio>
            @endforeach
    </div> --}}
    <div class="container">
        <div></div>
        <h6 style="text-align: center;padding:10px"> Audio is playing in the background</h6>
        <div></div>
        @foreach ($organizedData as $row)
        <iframe src="{{ asset($row['audio_file']) }}" class="audio-play" id="audio-player" allow="autoplay" style="display: none"></iframe>
        @endforeach
    </div>
    </nav>
    </div>

    <div class="container-fluid main-container">
        <!-- <h1>Listening Test</h1> -->

        <div class="container-fluid main-container position-relative">
            <div class="position-fixed" id="count_answer" style="
            top: 150px;
            right: 50px;
            border-radius: 10px;
            border: 1px solid green;
            padding: 10px 15px;
            font-size: 20px;
        ">

            </div>

        <div class="question-container">
            <div class="tab-content" id="pills-tabContent">
                @foreach ($organizedData as $row)
                @php
                $partInfo = json_decode($row['part_info'], true);
                @endphp

                @if (!empty($partInfo))
                @foreach ($partInfo as $part)
                <div class="tab-pane fade @if ($loop->first) show active @endif" id="pills-part{{ $part['id'] + 1 }}" role="tabpanel" aria-labelledby="pills-part{{ $part['id'] + 1 }}-tab" tabindex="0">
                    <div class="container-fluid">
                        <section class="test-panel" style="overflow-y: hidden; outline: none" tabindex="2">
                            <div class="test-panel__header">
                                <h2 class="test-panel__title">{{ $part['short_title'] }}</h2>
                                <div class="test-panel__title-caption"></div>
                            </div>
                            <div class="test-panel__item">
                                <!-- Rest of your content for Part 1 -->
                                <section class="test-panel" style="overflow-y: hidden; outline: none" tabindex="2">

                                    @foreach ($organizedData as $row)
                                    @php
                                    $questioninfo = $row['questions'];
                                    @endphp

                                    @if (!empty($questioninfo))
                                    @php
                                    $q_count = 0;
                                    @endphp
                                    @foreach ($questioninfo as $questionId => $question)
                                    @if ($q_count +1 >= $part['start'] && $q_count +1 <= $part['end']) <div class="test-panel__item" id=@php $c_input=substr_count($question['title'], '<input' ); if(!$c_input){ $temp_q=$q_count+1; echo 'ques-' . $temp_q; } @endphp>
                                        <div class="test-panel__question">
                                            <!-- <p>Part ID: {{ $part['id'] }}, Question ID: {{ $questionId }}, Q Count: {{ $q_count+1 }}, part start : {{$part['start']}} , part end : {{$part['end']}} ,</p> -->
                                            <h4 class="test-panel__question-title">
                                                Question
                                                @php
                                                $c_input = substr_count($question['title'], '<input'); if ($c_input==0 || $c_input==1) { $q_count +=1; echo $q_count; $temporary_count=$q_count;} else { $q_count +=1; echo $q_count; $temporary_count=$q_count; $q_count +=$c_input - 1; echo '-' . $q_count; } @endphp </h4>


                                                    <div class="test-panel__question-desc">
                                                        <div class="field field--name-field-question field--type-text-long field--label-hidden field--item">
                                                            <p>


                                                                <em>



                                                                    @php
                                                                    $start = $temporary_count; // Set your initial start value
                                                                    $modifiedTitle = preg_replace_callback('/<input /', function($matches) use (&$start) { return '<input id="ques-' . $start . '" placeholder="' . $start++ . '"' ; }, $question['title']); @endphp {!!$modifiedTitle!!} </em>
                                                            </p>
                                                        </div>
                                                    </div>
                                        </div>

                                        <div class="test-panel__answer">
                                            @foreach ($question['options'] as $optionKey => $option)
                                            <div class="test-panel__answer-item">
                                                <span class="test-panel__answer-option" style="font-weight: bold">({{ chr(65 + $optionKey) }})</span>
                                                <label class="iot-radio" for="q-{{ $questionId }}-{{ $optionKey }}">
                                                    <input type="radio" class="radio-iot iot-lr-question" id="q-{{ $questionId }}-{{ $optionKey }}" data-num="{{ $questionId }}" name="q-{{ $questionId }}" data-q_type="15" value="{{ $option['option'] }}" />
                                                    <span class="checkmark"></span>
                                                    <span class="cb-label">{{ $option['option'] }}</span>
                                                </label>
                                            </div>
                                            @endforeach
                                        </div>
                            </div>
                            @else
                            @php
                            $c_input = substr_count($question['title'], '<input'); if ($c_input==0 || $c_input==1) { $q_count +=1; } else { $q_count +=1; $q_count +=$c_input - 1; } @endphp @endif @endforeach @endif @endforeach </section>
                    </div>

                </div>
            </div>
            @endforeach
            @else
            No part info available.
            @endif
            @endforeach

        </div>
    </div>

    <div class="take-test__bottom-palette">
        <div class="container-fluid">
            <ul class="nav nav-pills mb-3 d-flex justify-content-center" id="pills-tab" role="tablist">
                @foreach ($organizedData as $row)
                @php
                $partInfo = json_decode($row['part_info'], true);
                @endphp
                @if (!empty($partInfo))
                @foreach ($partInfo as $part)
                <li class="nav-item" role="presentation">
                    <button class="nav-link {{ $loop->first ? 'active' : '' }} d-flex" id="pills-part{{ $part['id'] + 1 }}-tab" data-bs-toggle="pill" data-bs-target="#pills-part{{ $part['id'] + 1 }}" type="button" role="tab" aria-controls="pills-part{{ $part['id'] + 1 }}" aria-selected="{{ $loop->first ? 'true' : 'false' }}">
                        <div class="tab-name font-weight-bold me-1">
                            {{ $part['short_title'] }}:
                        </div>
                        <div class="tab-number">{{ $part['title'] }}</div>
                        <div class="tab-number-count">
                            @for ($i = $part['start']; $i <= $part['end']; $i++) <span onclick="scrollToQues('ques-{{ $i }}', event)">
                                <p>{{ $i }}</p>
                                </span>
                                @endfor
                        </div>
                    </button>
                </li>
                @endforeach
                @endif
                @endforeach
            </ul>
        </div>
    </div>
    </div>

    <!-- Include Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script></script>

    <div class="modal fade text-center" tabindex="-1" role="dialog" id="popupModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header justify-content-center">
                    <h5 class="modal-title text-center">Time is up!</h5>
                    <!-- <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button> -->
                </div>
                <div class="modal-body">
                    <p id="modalMessage"></p>
                    {{-- <p class="modal-des">
                        However, we realize that you have not completed the test yet.
                        <br />
                        Please click the "Retake" button below to take the test again
                        before submitting.
                    </p>
                    <div class="modal-body">

                        <button class="iot-bt btn btn-danger" href="#" onclick="reloadPage()">
                            Retake
                        </button>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>
<script>
    // Function to reload the page
    function reloadPage() {
        location.reload();
    }

    let isSubmitting = false;

    const onConfirmRefresh = function(event) {
        if (!isSubmitting) {
            const confirmationMessage = "If you leave, your answers will be submitted.";
            event.returnValue = confirmationMessage;
        }
    }

    window.addEventListener("beforeunload", onConfirmRefresh, {
        capture: true
    });

    $(document).ready(function() {
        let questionOptions = {};
        let questionSetId;
        let examDuration = 40; // Default value

        @foreach ($organizedData as $row)
            @php
                $questionSetId = $row['question_set_id'];
                $questioninfo = $row['questions'];
                $examDuration = $row['exam_duration']; // Get exam_duration from PHP variable
            @endphp
            questionSetId = {{ $questionSetId }};
            examDuration = {{ $examDuration }}; // Assign PHP value to JavaScript variable
            @if (!empty($questioninfo))
                @foreach ($questioninfo as $questionId => $question)
                    questionOptions[{{ $questionId }}] = [
                        @foreach ($question['options'] as $optionKey => $option)
                            {
                                question_id: {{ $questionId }},
                                index: {{ $optionKey }},
                                text: "{{ $option['option'] }}"
                            },
                        @endforeach
                    ];
                @endforeach
            @endif
        @endforeach

        let countdown;
        // const countdownDuration = 1 * 60; // 1 minute (for testing)
        // const countdownDuration = 40 * 60;
        const countdownDuration = examDuration * 60; // Use examDuration here

        function updateCountdown() {
            const minutes = Math.floor(countdown / 60);
            const seconds = countdown % 60;
            const countdownDisplay = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
            document.getElementById("time-counter").textContent = countdownDisplay;

            if (countdown === 0) {
                clearInterval(interval);
                showPopUpAndSubmit();
            }
            countdown--;
        }

        function showPopUpAndSubmit() {
            isSubmitting = true; // Set the flag to prevent the confirmation message
            const popUpMessage = "Time's up! Your answers will be submitted automatically.";

            // Show Bootstrap modal with the message
            const modal = new bootstrap.Modal(document.getElementById("popupModal"));
            const modalMessage = document.getElementById("modalMessage");
            modalMessage.textContent = popUpMessage;
            modal.show();

            // Automatically submit the form after a delay (adjust the delay as needed)
            setTimeout(submitForm, 1000); // 5 seconds delay before submission
        }

        function submitForm() {
            let selectedOptions = {};
            mydata = "";
            $('input[type="radio"]:checked').each(function() {
                let questionId = $(this).data('num');
                let optionIndex = $(this).val();
                selectedOptions[questionId] = optionIndex;
                mydata = mydata + "Question " + questionId + ": " + optionIndex + "\n";
            });

            $('input[type="text"]').each(function() {
                let questionId = $(this).data('num');
                let optionIndex = $(this).val();
                selectedOptions[questionId] = optionIndex;
                mydata = mydata + "Question " + questionId + ": " + optionIndex + "\n";
            });

            console.log(mydata);

            // let selectedOptionsData = [];
            // for (let questionId in selectedOptions) {
            //     let optionIndex = selectedOptions[questionId];
            //     let optionData = questionOptions[questionId] ? questionOptions[questionId][optionIndex] : null;

            //     if (optionData) {
            //         selectedOptionsData.push(optionData);
            //     }
            // }

            // let selectedOptionsString = selectedOptionsData.map(function(option) {
            //     return `Question ${option.question_id}: ${option.text}`;
            // }).join('\n');

            // let data = selectedOptionsString;
            let csrfToken = $('meta[name="csrf-token"]').attr('content');

            // console.log(data);

            $.ajax({
                url: "{{ route('general-listening-test-score') }}",
                type: 'POST',
                data: {
                    selectedOptions: mydata,
                    questionSetId: questionSetId,
                    _token: csrfToken,
                },
                success: function(response) {
                    window.location.href = "/test_score";
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        $('.bt-submit').click(function() {
            submitForm();
        });

        // Start the countdown automatically
        countdown = countdownDuration;
        updateCountdown();
        const interval = setInterval(updateCountdown, 1000);
    });


    // count all answer

    function countSelectedRadios() {
            const radioGroups = document.querySelectorAll('input[type="radio"]:checked');
            return radioGroups.length;
        }

        function countFilledTextInputs() {
            const textInputElements = document.querySelectorAll('input[type="text"]');
            let count = 0;

            textInputElements.forEach(input => {
                if (input.value.trim() !== '') {
                    count++;
                }
            });

            return count;
        }

        function updateCount() {
            const selectedRadiosCount = countSelectedRadios();
            const filledTextInputCount = countFilledTextInputs();
            let total_ans = selectedRadiosCount + filledTextInputCount;

            document.getElementById('count_answer').innerHTML = total_ans + "/40";
        }

        // Attach the updateCount function to relevant events (e.g., change, input, etc.)
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', updateCount);
        });

        document.querySelectorAll('input[type="text"]').forEach(input => {
            input.addEventListener('input', updateCount);
        });

        // Initial count on page load
        updateCount();
</script>
</html>
